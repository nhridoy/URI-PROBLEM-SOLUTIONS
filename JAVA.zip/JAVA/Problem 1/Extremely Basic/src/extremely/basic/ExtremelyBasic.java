
package extremely.basic;

import java.util.Scanner;

public class ExtremelyBasic {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a,b,x;
        a = input.nextInt();
        b = input.nextInt();
        x = a + b;
        System.out.println("X = "+x);
    }
    
}
