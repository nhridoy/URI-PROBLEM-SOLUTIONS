
package distance;

import java.util.Scanner;

/**
 *
 * @author Hridoy
 */
public class Distance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a,d;
        a = input.nextInt();
        d = 2*a;
        System.out.println(d+" minutos");
    }
    
}
